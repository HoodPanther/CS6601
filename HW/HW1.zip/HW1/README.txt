This code requires:
python 2.7: http://www.python.org/download/releases/2.7/
ipython: http://ipython.org/install.html
ipython Notebook: http://ipython.org/notebook.html

Basically what comes with Continuum's python tool
Anaconda: https://store.continuum.io/cshop/anaconda/
    OR! more specifically here:
    matplotlib: http://matplotlib.org/
    pandas: http://pandas.pydata.org/
    numpy: http://www.numpy.org/

But if you're feeling lazy,
go ahead and get a free Python cloud server with
Wakari: https://wakari.io/
and you'll have everything you'll need,
and can run the code and see the results with just a web browser.
I would reconmend this,
as that is what I've written this code with.

Open up my Search.ipynb with ipython Notebook
you can read through the note book
or step through the cell execution by hitting 'shift' + 'enter'
